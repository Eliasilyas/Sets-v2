let ws, token = '', running = false, tradeCooldown = false;

const log = (msg) => {
  const logDiv = document.getElementById("log");
  logDiv.innerText += `\n[${new Date().toLocaleTimeString()}] ${msg}`;
  logDiv.scrollTop = logDiv.scrollHeight;
};

const connect = () => {
  token = document.getElementById("token").value.trim();
  if (!token) {
    log("❗ Please enter a valid Deriv token.");
    return;
  }

  ws = new WebSocket("wss://ws.deriv.com/websockets/v3");

  ws.onopen = () => {
    log("🔗 Connected to Deriv.");
    ws.send(JSON.stringify({ authorize: token }));
  };

  ws.onmessage = (msg) => {
    const data = JSON.parse(msg.data);

    if (data.error) {
      log("❌ Error: " + data.error.message);
      return;
    }

    if (data.msg_type === "authorize") {
      log("✅ Authorized with token ending in: " + data.authorize.loginid.slice(-6));
    }

    if (data.msg_type === "tick" && running) {
      const price = data.tick.quote.toFixed(2);
      const time = data.tick.epoch;
      log(`📍 Tick | Price: ${price} | Time: ${time}`);

      const energy = simulateEnergy(price);
      const rhythm = simulateRhythm();

      if (rhythm === "stable") log("🌀 Stable Rhythm Detected");
      if (energy === "low") {
        log("🧊 Low Energy");
        log("🚫 META-ENERGY BLOCK: Conditions Not Aligned");
        return;
      } else {
        log("⚡ Normal Energy Flow");
        log("✅ META-ENERGY ALIGNMENT: Entry Window");
      }

      if (simulateWhiplash()) {
        log("⚠️ Whiplash Detected – Awaiting Double-Confirmation...");
        setTimeout(() => {
          log("✅ Whiplash Confirmed");
          const delay = Math.floor(Math.random() * 100) + 150;
          log(`⏳ Micro Delay: ${delay}ms before entry...`);
          setTimeout(() => {
            if (!tradeCooldown) {
              log("📈 Trade Executed ⚡");
              tradeCooldown = true;
              setTimeout(() => {
                tradeCooldown = false;
              }, 7000); // Anti-Greed Cooldown
            } else {
              log("⛔ Trade Skipped (Anti-Greed Cooldown)");
            }
          }, delay);
        }, 200);
      } else {
        if (tradeCooldown) {
          log("⛔ Trade Skipped (Anti-Greed Cooldown)");
        }
      }
    }
  };

  ws.onerror = (err) => {
    log("❌ WebSocket error (debug): Check browser console.");
    console.error(err);
  };

  ws.onclose = () => {
    log("🔌 Disconnected from Deriv.");
  };
};

const start = () => {
  if (!ws || ws.readyState !== 1) {
    log("❗ Please connect first.");
    return;
  }
  log("🚀 SETS V2+ Energy Engine Started.");
  ws.send(JSON.stringify({ ticks: "R_100", subscribe: 1 }));
  running = true;
};

const stop = () => {
  if (ws) {
    ws.send(JSON.stringify({ forget_all: "ticks" }));
    log("🛑 SETS V2+ Stopped.");
    running = false;
  }
};

const simulateEnergy = (price) => {
  return Math.random() < 0.25 ? "low" : "normal";
};

const simulateRhythm = () => {
  return Math.random() < 0.4 ? "stable" : "chaotic";
};

const simulateWhiplash = () => {
  return Math.random() < 0.2;
};